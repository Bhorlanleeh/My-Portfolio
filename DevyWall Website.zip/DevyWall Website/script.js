// let images = ["img/programming-background-with-person-working-with-codes-computer", "img/img2", "img/img3", "img/img4", "img/img5"]
// let index = 0;
// const slideshow_image = document.querySelector ("#slideshow_image")

// function on () {
//     slideshow_image.src = images[index];
//     index > 1 ? index = 0 : index++;
// }

// window.onload = function () {
//     setInterval(on, 7000);
// }